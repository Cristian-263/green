import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Role } from 'src/constants/enums/role.enum';
import { AuthenticatedRequest } from 'src/constants/interfaces/authenticatedRequest.interface';

import { ROLES_KEY } from '../decorators/roles.decorator';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<Role[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if(!requiredRoles) return true;

    const user = context.switchToHttp().getRequest<AuthenticatedRequest>().user;
    return requiredRoles.some((role) => {
      return (user.role as Role) === role;
    });
  }
}
