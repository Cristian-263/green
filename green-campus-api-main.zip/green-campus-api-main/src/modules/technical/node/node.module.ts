import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { Node } from './entities/node.entity';
import { NodeController } from './node.controller';
import { NodeService } from './node.service';
import { Reading } from '../reading/entities/reading.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Node]), TypeOrmModule.forFeature([Reading])],
  controllers: [NodeController],
  providers: [NodeService],
})
export class NodeModule {}
